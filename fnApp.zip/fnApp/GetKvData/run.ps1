using  namespace  System.Net
param($Request, $TriggerMetadata)

Write-Host  "PowerShell HTTP trigger function processed a request."
Import-Module -Name 'AzureAD' -UseWindowsPowershell

#######################################################################
#Standard Variables
$resourceGroup=$env:APPSETTING_appresourceGroup
$storageName=$env:APPSETTING_appstorageName
$Useridentity = $env:APPSETTING_appUseridentity
$tableName = $env:APPSETTING_apptableName
$mainkeyvault=$env:APPSETTING_appkeyvaultName
$username="NA"
$secret="NA"

#Variables Azure AD for Password Reset
$tenant = $env:APPSETTING_apptenant
$adusername=$env:APPSETTING_appaduser
$addomain=$env:APPSETTING_appdomain
###############################################################################################################

$rndnum=Get-Date -Format "dd-MM-ms"
$Nme= $Request.Headers['X-MS-CLIENT-PRINCIPAL-NAME']
$currentDate=Get-Date
$AccessedOn=$currentDate.ToString('yyyy-MM-ddTHH:mm:ss.msZ') 


$AppName = $Request.Query.AppName
if (-not $AppName) {
    $body="Please supply 'AppName' parameter for which you want to get the credentials."     
}
else {
try {  
$ExpiryHours = [int]$Request.Query.ExpiryHours
if (-not $ExpiryHours) {
    $body="Please supply 'ExpiryHours' parameter to set the expiry" 
}
elseif (!($ExpiryHours -ge 0 -and $ExpiryHours -le 5)) {
        $body="Please supply 'ExpiryHours' parameter between 1 to 5"     
}
else {

$ExpiryHours=[Math]::Round($ExpiryHours, 0)
$ExpiryDate=$currentDate.AddHours($ExpiryHours).ToString('yyyy-MM-ddTHH:mm:ss.msZ') 

# Remove all the existing context in the seemless process
Disable-AzContextAutosave -Scope Process

# Connect to Azure with user-assigned managed identity and set context
$AzureContext = (Connect-AzAccount -Identity -AccountId $Useridentity).context
$AzureContext = Set-AzContext -SubscriptionName $AzureContext.Subscription -DefaultProfile $AzureContext

$storageAccount=Get-AzStorageAccount -ResourceGroupName $resourceGroup -Name $storageName
$ctx = $storageAccount.Context

#To Validate if data is coming
Write-Host  $ctx.ConnectionString

#Internal Variables
$keyvaultName="kv3-$AppName"
$appgrpName="grp$AppName"
$appprivgrpName="grppriv$AppName"


#Pull Data from storage account table
$stTable = (Get-AzStorageTable -Name $tableName -Context $ctx).CloudTable
Write-Host  $stTable.Name

#Pull all the data in table format
$stTableRows = Get-AzTableRow -table $stTable -CustomFilter "(Status eq 'Active') and (AppName eq '$AppName')" 
$UsedLoginUsers = ""
foreach ($stTableRow in $stTableRows) {
    $username = $stTableRow.Username 
    $UsedLoginUsers += "`n$username"
}
  
$aduserid=$adusername+$addomain
$adpassword = Get-AzKeyVaultSecret -VaultName $mainkeyvault -Name $adusername -AsPlainText 
$secureStringPwd = $adpassword|ConvertTo-SecureString -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential ($aduserid, $secureStringPwd)
Connect-AzureAD -TenantId $tenant -credential $credential  

[string]$adgroupid = (Get-AzureADGroup -SearchString $appprivgrpName).ObjectId
$loggeduserid = (Get-AzureADUser -ObjectId  $Nme).ObjectId
[string]$groupmemberof = Get-AzureADUserMembership -ObjectId $loggeduserid | select ObjectId -ExpandProperty ObjectId
If ($groupmemberof -match $adgroupid) {
     $userExists= $true
} Else {
     $userExists= $false
}
$userExists

    if ($userExists) {
        [string]$appgroupid = (Get-AzureADGroup -SearchString $appgrpName).ObjectId
        $GrpAppUsers=Get-AzureADGroupMember -ObjectId $appgroupid -ErrorAction SilentlyContinue | Select-Object -ExpandProperty DisplayName
        foreach($GrpAppUser in $GrpAppUsers)
        {
            if($UsedLoginUsers -inotmatch $GrpAppUser)
            {
                Write-Host  "If $GrpAppUser"
                $username= $GrpAppUser
                $secret = Get-AzKeyVaultSecret -VaultName $keyvaultName -Name $GrpAppUser -AsPlainText
                break
            }
        }
        if($secret -eq "NA")
        {
            $body="All the account being used or not  please try again after some time!"
        }
        else {
            $body = "Please use the [$secret] password for user '$username'"
            Add-AzTableRow -table $stTable -partitionKey "Pk01" -rowKey ("rw-$rndnum") -property @{"Caller"=$Nme;"AppName"=$AppName;"UserName"=$username;"AccessedKeyVault"=$keyvaultName;"KVSecretName"=$username;"AccessedOn"=$AccessedOn;"ExpiredBy"=$ExpiryDate;"Status"="Active"}
        }
    }
    else
    {
        $body = "The logged in user $usernamee is not authorized to get the user detail. "
    }      
}
}
catch {
    $body = "Something went wrong, please validate the parameters"
}
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
StatusCode = [HttpStatusCode]::OK
Body = $body
})
