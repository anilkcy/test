using  namespace  System.Net
param($Request, $TriggerMetadata)

Write-Host  "PowerShell HTTP trigger function processed a request."
Import-Module -Name 'AzureAD' -UseWindowsPowershell


####################################################################
# Generate Password Function
####################################################################

function Shuffle-String([string]$inputString) {
    $charArray = $inputString.ToCharArray()
    $rng = New-Object System.Random
    $remainingChars = $charArray.length
    while ($remainingChars -gt 1) {
        $remainingChars--
        $charIndex = $rng.Next($remainingChars + 1)
        $value = $charArray[$charIndex]
        $charArray[$charIndex] = $charArray[$remainingChars]
        $charArray[$remainingChars] = $value
    }
    return -join $charArray
  }
  
  function GeneratePassword() {
      $TokenSet = @{
            U = [Char[]]'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
            L = [Char[]]'abcdefghijklmnopqrstuvwxyz'
            N = [Char[]]'0123456789'
      }
     
      $Upper = Get-Random -Count 3 -InputObject $TokenSet.U
      $Lower = Get-Random -Count 3 -InputObject $TokenSet.L
      $Number = Get-Random -Count 3 -InputObject $TokenSet.N
      $Combined = ($Upper + $Lower + $Number + $Special) -join ''
    
      return Shuffle-String $Combined
  }

  
###############################################################################################################
#Standard Variables
$resourceGroup=$env:APPSETTING_appresourceGroup
$storageName=$env:APPSETTING_appstorageName
$Useridentity = $env:APPSETTING_appUseridentity
$tableName = $env:APPSETTING_apptableName
$mainkeyvault=$env:APPSETTING_appkeyvaultName

#Variables Azure AD for Password Reset
$tenant = $env:APPSETTING_apptenant
$adusername=$env:APPSETTING_appaduser
$addomain=$env:APPSETTING_appdomain
###############################################################################################################


# Remove all the existing context in the seemless process
Disable-AzContextAutosave -Scope Process

# Connect to Azure with user-assigned managed identity and set context
$AzureContext = (Connect-AzAccount -Identity -AccountId $Useridentity).context
$AzureContext = Set-AzContext -SubscriptionName $AzureContext.Subscription -DefaultProfile $AzureContext

$storageAccount=Get-AzStorageAccount -ResourceGroupName $resourceGroup -Name $storageName
$ctx = $storageAccount.Context

Write-Host  $ctx.ConnectionString

#Pull Data from storage account table
$stTable = (Get-AzStorageTable -Name $tableName -Context $ctx).CloudTable
Write-Host  $stTable.Name

#Pull all the data in table format
$stTableRow = Get-AzTableRow -table $stTable  -CustomFilter "(Status eq 'Active')"



if($stTableRow.Length -eq 0)
{
    $body="There is no user to release."
}
elseif($stTableRow.Length -gt 0)
{
    for ($i=0; $i -le $stTableRow.Length-1; $i++) {   
        $AppNm=$stTableRow[$i].AppName
        $keyvaultName="kv3-$AppNm"     
        $stTableRow[$i].Status='Closed'
        $stTableRow[$i] | Update-AzTableRow -table $stTable
        $newPassword = GeneratePassword   
        $aduserid=$adusername+$addomain 
        $adpassword = Get-AzKeyVaultSecret -VaultName $mainkeyvault -Name $adusername -AsPlainText 
        $secureStringPwd = $adpassword|ConvertTo-SecureString -AsPlainText -Force
        $credential = New-Object System.Management.Automation.PSCredential ($aduserid, $secureStringPwd)
        Connect-AzureAD -TenantId $tenant -credential $credential
        $lclUsr=$stTableRow[$i].UserName   
        $sqPassword = ConvertTo-SecureString -String $newPassword -AsPlainText -Force
        Set-AzureADUserPassword -ObjectId "$lclUsr$addomain" -Password $sqPassword    
        Set-AzKeyVaultSecret -VaultName $keyvaultName -Name $lclUsr -SecretValue $sqPassword
        $body="The password is reset and updated for all users."
        }        
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
StatusCode = [HttpStatusCode]::OK
Body = $body
})